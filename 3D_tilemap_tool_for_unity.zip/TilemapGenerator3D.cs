using UnityEngine;
[ExecuteInEditMode]
public class TileMapGenerator3D : MonoBehaviour
{
    [HideInInspector] public GameObject[] tiles;
    [HideInInspector] public Color[] colors;
    [SerializeField] private GameObject Empty;
    [Header("Grid Settings")]
    [HideInInspector] public int matrixX;
    [HideInInspector] public int matrixZ;
    [HideInInspector] public int matrixY;
    [HideInInspector] public float gridSize;
    [HideInInspector] public int currentLayer;
    public int[,,] grid; // x,z,y | grid[x,z,y] = a; tiles[a] & colors[a]
    [HideInInspector] public int _brushNum;
    public void InitiateGrid()
    {
        // New matrix as grid -->
        grid = new int[matrixX, matrixZ, matrixY];
        // <--

        // Set all matrix values like -1 -->
        for (int y = 0; y < grid.GetLength(2); y++){
            for (int z = 0; z < grid.GetLength(1); z++){
                for (int x = 0; x < grid.GetLength(0); x++){
                    grid[x,z,y] = -1;
                }
            }
        }
        // <--
    }
    public void GenerateMap(){
        GameObject map = Instantiate(Empty, transform.position, transform.rotation, transform);
        map.name = "Map";
        for (int y = 0; y < grid.GetLength(2); y++)
        {
            GameObject layer = Instantiate(Empty, transform.position, transform.rotation, map.transform);
            layer.name = $"Layer {y}";
            for (int x = 0; x < grid.GetLength(0); x++)
            {
                for (int z = 0; z < grid.GetLength(1); z++)
                {
                    if(grid[x,z,y] >= 0){
                        GameObject tObj = Instantiate(tiles[grid[x,z,y]], new Vector3(x,y,-z), transform.rotation, layer.transform);
                        tObj.name = $"Tile({x},{z})";
                    }
                }
            }
        }
    }
    public void CheckGridMatrix(){ // Matrix checking
        string matrix = string.Empty;
        for (int y = 0; y < grid.GetLength(2); y++){
            for (int z = 0; z < grid.GetLength(1); z++){
                for (int x = 0; x < grid.GetLength(0); x++){
                    matrix += $"{grid[x,z,y]} ";
                }
                matrix += "\n";
            }
            matrix += "\n\n";
        }
        print(matrix);
    }
}
