using UnityEditor;
using UnityEngine;
[CustomEditor(typeof(TileMapGenerator3D))]
public class TileMapGenerator3DEditor : Editor
{
    private bool isPainting = false;
    private TileMapGenerator3D tileMapGenerator3D;
    public SerializedProperty Tiles;
    public SerializedProperty Colors;

    // Variables get, set -->
    public int MatrixX{
        get => tileMapGenerator3D.matrixX;
        set{
            if (value < 1) tileMapGenerator3D.matrixX = 1;
            else tileMapGenerator3D.matrixX = value;
        }
    }
    public int MatrixZ{
        get => tileMapGenerator3D.matrixZ;
        set{
            if (value < 1) tileMapGenerator3D.matrixZ = 1;
            else tileMapGenerator3D.matrixZ = value;
        }
    }
    public int MatrixY{
        get => tileMapGenerator3D.matrixY;
        set{
            if (value < 1) tileMapGenerator3D.matrixY = 1;
            else tileMapGenerator3D.matrixY = value;
        }
    }
    public float GridSize{
        get => tileMapGenerator3D.gridSize;
        set{
            if(value < 5) tileMapGenerator3D.gridSize = 5;
            else if(value > 50) tileMapGenerator3D.gridSize = 50;
            else tileMapGenerator3D.gridSize = value;
        }
    }
    public int BrushNum{
        get => tileMapGenerator3D._brushNum;
        set{
            if (value > tileMapGenerator3D.tiles.Length-1) tileMapGenerator3D._brushNum = tileMapGenerator3D.tiles.Length-1;
            else if (value < 0) tileMapGenerator3D._brushNum = 0;
            else tileMapGenerator3D._brushNum = value;
        }
    }
    public tool currentTool;
    public int CurrentLayer{
        get => tileMapGenerator3D.currentLayer;
        set{
            if(value >= tileMapGenerator3D.grid.GetLength(2)) tileMapGenerator3D.currentLayer = tileMapGenerator3D.grid.GetLength(2)-1;
            else if(value < 0) tileMapGenerator3D.currentLayer = 0;
            else tileMapGenerator3D.currentLayer = value;
        }
    }
    // <--

    private void OnEnable()
    {
        // Get target script & properity arrays -->
        tileMapGenerator3D = (TileMapGenerator3D)target;
        Tiles = serializedObject.FindProperty("tiles");
        Colors = serializedObject.FindProperty("colors");
        // <--

        if (tileMapGenerator3D.grid == null)
        {
            tileMapGenerator3D.InitiateGrid();
        }
    }
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();
        // Tile objects & them colors --> 
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.PropertyField(Tiles,new GUIContent("GameObject Listesi"),true);
        EditorGUILayout.PropertyField(Colors,new GUIContent("Color"),true);
        Colors.arraySize = Tiles.arraySize;
        serializedObject.ApplyModifiedProperties(); // Apply changes
        EditorGUILayout.EndHorizontal();
        // <--

        // Matrix dimensions size -->
        MatrixX = EditorGUILayout.IntField("Matrix X",MatrixX);
        MatrixZ = EditorGUILayout.IntField("Matrix Z",MatrixZ);
        MatrixY = EditorGUILayout.IntField("Matrix Y",MatrixY);
        // <--

        // Grid size on inspector view -->
        GridSize = EditorGUILayout.FloatField("Grid Size", GridSize);
        // <--

        // Grid initiate & reset & resize button -->
        if (GUILayout.Button("Initiate/Reset/Resize Grid")){
            tileMapGenerator3D.InitiateGrid();
        }
        // <--

        // Painting properities -->
        BrushNum = EditorGUILayout.IntField("Brush Number", BrushNum);
        currentTool = (tool)EditorGUILayout.EnumPopup("Tool type", currentTool);
        CurrentLayer = EditorGUILayout.IntField("Layer", CurrentLayer);
        // <--

        // Draw Grid function -->
        DrawGrid();
        // <--

        // Matrix checking button -->
        if(GUILayout.Button("Check Grid Matrix")){
            tileMapGenerator3D.CheckGridMatrix();
        }
        // <--

        // Map generating button -->
        if (GUILayout.Button("Generate Map")){
            // Checking play mod -->
            if (!Application.isPlaying){
                Undo.RecordObject(tileMapGenerator3D, "Generate Map");
                tileMapGenerator3D.GenerateMap();
                EditorUtility.SetDirty(tileMapGenerator3D);
            }
            else{
                Debug.LogWarning("Map can't generate on play mode");
            }
            // <--
        }
        // <--
    }
    private void DrawGrid(){
        // Genetare grid on inspector -->
        for (int z = 0; z < tileMapGenerator3D.grid.GetLength(1); z++){
            EditorGUILayout.BeginHorizontal();
            for (int x = 0; x < tileMapGenerator3D.grid.GetLength(0); x++){

                // Color settings for grid cell -->
                Color boxColor = new Color(0,0,0,1);
                for (int y = 1; y <= CurrentLayer+1; y++){
                    float colorMult = (float)y/(float)tileMapGenerator3D.grid.GetLength(2);
                    for (int b = 0; b < tileMapGenerator3D.colors.Length; b++){
                        tileMapGenerator3D.colors[b].a = colorMult;
                    }
                    if(tileMapGenerator3D.grid[x,z,y-1] >= 0) {
                        boxColor = tileMapGenerator3D.colors[tileMapGenerator3D.grid[x,z,y-1]];
                    }
                }
                // <--
                // Draw grid cell -->
                EditorGUI.DrawRect(EditorGUILayout.GetControlRect(GUILayout.Width(GridSize), GUILayout.Height(GridSize)), boxColor);
                    // Add Mouse actions -->
                    Rect cellRect = GUILayoutUtility.GetLastRect();
                    Event currentEvent = Event.current;
                    if (currentEvent.type == EventType.MouseDown && cellRect.Contains(currentEvent.mousePosition)){ // click
                        isPainting = true;
                        if(currentTool == tool.brush) tileMapGenerator3D.grid[x,z,CurrentLayer] = BrushNum;
                        else if(currentTool == tool.eraser) tileMapGenerator3D.grid[x,z,CurrentLayer] = -1;
                        EditorUtility.SetDirty(tileMapGenerator3D);
                        currentEvent.Use();
                    }
                    else if (currentEvent.type == EventType.MouseDrag && cellRect.Contains(currentEvent.mousePosition) && isPainting){ // drag
                        if(currentTool == tool.brush) tileMapGenerator3D.grid[x,z,CurrentLayer] = BrushNum;
                        else if(currentTool == tool.eraser) tileMapGenerator3D.grid[x,z,CurrentLayer] = -1;
                        EditorUtility.SetDirty(tileMapGenerator3D);
                        currentEvent.Use();
                    }
                    else if (currentEvent.type == EventType.MouseUp){ // end
                        isPainting = false;
                    }
                    // <--
                // <--
            }
            EditorGUILayout.EndHorizontal();
        }
        // <--
    }
    public enum tool{
        brush,
        eraser
    }
}